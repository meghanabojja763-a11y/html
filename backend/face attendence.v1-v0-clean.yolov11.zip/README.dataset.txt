# face attendence > v0-clean
https://universe.roboflow.com/face-detection-guci5/face-attendence

Provided by a Roboflow user
License: CC BY 4.0

